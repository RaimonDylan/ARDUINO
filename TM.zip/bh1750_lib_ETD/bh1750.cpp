#include "bh1750.h"

BH1750::BH1750(){
  
}

void BH1750::begin(){
 
 
  
}

uint16_t BH1750::getRawLight(void){
     
} 


void BH1750::i2cWrite8( uint8_t data ) {
  
}

uint16_t BH1750::i2cRead16(  ) {
   

}
